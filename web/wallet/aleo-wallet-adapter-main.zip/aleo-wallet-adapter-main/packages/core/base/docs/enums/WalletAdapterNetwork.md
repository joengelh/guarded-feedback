[@demox-labs/aleo-wallet-adapter-base](../README.md) / [Exports](../modules.md) / WalletAdapterNetwork

# Enumeration: WalletAdapterNetwork

## Table of contents

### Enumeration Members

- [Testnet](WalletAdapterNetwork.md#testnet)

## Enumeration Members

### Testnet

• **Testnet** = ``"testnet3"``

#### Defined in

[types.ts:2](https://github.com/demox-labs/leo-wallet-adapter/blob/10fbe90/packages/core/base/types.ts#L2)
