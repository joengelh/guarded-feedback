[@demox-labs/aleo-wallet-adapter-base](../README.md) / [Exports](../modules.md) / [EventEmitter](../modules/EventEmitter.md) / EventEmitterStatic

# Interface: EventEmitterStatic

[EventEmitter](../modules/EventEmitter.md).EventEmitterStatic

## Table of contents

### Constructors

- [constructor](EventEmitter.EventEmitterStatic.md#constructor)

## Constructors

### constructor

• **new EventEmitterStatic**<`EventTypes`, `Context`\>()

#### Type parameters

| Name | Type |
| :------ | :------ |
| `EventTypes` | extends [`ValidEventTypes`](../modules/EventEmitter.md#valideventtypes) = `string` \| `symbol` |
| `Context` | `any` |

#### Defined in

node_modules/eventemitter3/index.d.ts:88
