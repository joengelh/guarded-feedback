[@demox-labs/aleo-wallet-adapter-leo](../README.md) / [Exports](../modules.md) / LeoWalletAdapterConfig

# Interface: LeoWalletAdapterConfig

## Table of contents

### Properties

- [appName](LeoWalletAdapterConfig.md#appname)

## Properties

### appName

• `Optional` **appName**: `string`

#### Defined in

[adapter.ts:52](https://github.com/demox-labs/leo-wallet-adapter/blob/10fbe90/packages/wallets/leo/adapter.ts#L52)
