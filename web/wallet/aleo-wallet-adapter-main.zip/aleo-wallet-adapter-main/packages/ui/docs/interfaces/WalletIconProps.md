[@demox-labs/aleo-wallet-adapter-reactui](../README.md) / [Exports](../modules.md) / WalletIconProps

# Interface: WalletIconProps

## Hierarchy

- `unknown`<`ImgHTMLAttributes`<`HTMLImageElement`\>, `HTMLImageElement`\>

  ↳ **`WalletIconProps`**

## Table of contents

### Properties

- [wallet](WalletIconProps.md#wallet)

## Properties

### wallet

• **wallet**: ``null`` \| `Wallet`

#### Defined in

[WalletIcon.tsx:6](https://github.com/demox-labs/leo-wallet-adapter/blob/10fbe90/packages/ui/src/WalletIcon.tsx#L6)
